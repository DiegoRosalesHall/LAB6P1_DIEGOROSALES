package lab6p1_diegorosales;
import java.util.Scanner;
import java.util.Random;
public class LAB6P1_DiegoRosales {
    static Scanner mcgregor= new Scanner(System.in);
    static Random rand = new Random();
    public static char [] genRandCharArray(int p1){
        
        char charset [] = new char[p1];
        for(int i=0;i<p1;i++){
        int random_number = rand.nextInt(65,73);
        charset[i] = (char)random_number;
       }
        
       return charset;
    
    }// FIN METHOD GENRANDCHARARRAY
   
     public static void imprimir(char [] print){
        for (int i = 0; i < print.length; i++){
            System.out.print("[ " + print [i]+" ]");
        }
    }// FIN METHOD IMPRIMIR
      public static void  imprimir1 (int [] print){
        for (int i = 0; i < print.length; i++){
            System.out.print("[ " + print [i]+" ]");
        }
    }// FIN METHOD IMPRIMIR INT
     
      
      
      
      
      
      public static int [] gettotalprimecount(int [] p){
         int new_array [] = new int[p.length];
         for(int i =0;i<p.length;i++){
             new_array[i] = countPrimeFactors (p [i]);
             
                 
                 
                 
                 
             }
         return new_array;
         }
     public static int countPrimeFactors(int m){
         int primo = 0;
         boolean primo1;
         for (int i=1; i<=m;i++){
             primo1 = isPrime(i);
             if(primo1 == true && (m%i==0)){
                 primo++;
             }
         }
         return primo;
     } 
     public static boolean isPrime(int b){
         int x=0;
         boolean primo;
         for (int i =1;i<=b;i++){
             if(b%i ==0){
                 x++;
             }
         }
         if ( x==2){
             primo=true;
             
         }
         else{ 
             primo = false;
         }
         
      return primo;   
     } 
  
     public static int [] genRandArray(int tamano,int minimo,int maximo) {
           int randarray []= new int[tamano];
           
           for(int i=0;i<randarray.length;i++){
           int random = rand.nextInt(minimo,maximo);
           randarray[i]=random;
           }
           
        return randarray;   
       }
        

    
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     public static void main(String[] args) {
        int x=1;
        
        while(x==1){
        System.out.println("");
        System.out.println("Bienvenido al menu! ");
        
        System.out.println("1.~ Conjuntos");
        System.out.println("2.~  Cuantos primos tienes? ");
        System.out.println("3.~ Fin del Menu");
        int opcion_menu = mcgregor.nextInt();
        switch(opcion_menu){
            
            case 1:
                System.out.println("Inserte Set 1:");
                int set1 = mcgregor.nextInt();
                System.out.println("Inserte Set 2:");
                int set2 = mcgregor.nextInt();
                
               //SET 1 CONJUNTO
                char valor1 [] = new char[set1];
                valor1 = genRandCharArray(set1);
                System.out.println("Set 1:");
                imprimir(valor1);
                
                
                //SET 2 CONJUNTO
                char valor2 [] = new char[set2];
                valor2 = genRandCharArray(set2);
                System.out.println("");
                System.out.println("Set 2:");
                imprimir(valor2);
                
                
                System.out.println("");
                System.out.println("1.~ INTERSECCION");
                System.out.println("2.~ DIFERENCIA");
                int eleccion = mcgregor.nextInt();
                
                
                if(eleccion==1){
                   
                }
                break;
            
            
            case 2:
                System.out.println("Inserte el tamaño: ");
                int tamano1=mcgregor.nextInt();
                 System.out.println("Inserte el limite inferior: ");
                int minimo1=mcgregor.nextInt();
                 System.out.println("Inserte el limite superior: ");
                int maximo1=mcgregor.nextInt();
                int set [] = new int [tamano1];
                set= genRandArray(tamano1,minimo1,maximo1);
                System.out.println("Arreglo generado: ");
                System.out.println("");
                imprimir1 (set);
                System.out.println("");
                System.out.println(" numero de divisores primos: ");
                System.out.println(" ");
                int primos [] = new int [tamano1];
                primos=gettotalprimecount(set);
                System.out.println("");
                imprimir1(primos);
                
                break;
            
            
            case 3:
                System.out.println("HA FINALIZADO EL MENU");
                x=2;
                break;
                
            
            
        }// FIN DEL SWITCH
        }
    }
    
}


